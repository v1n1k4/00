/**
 * CLAEX MOTOR — INTERACTIVE CONTROLLERS
 * - Interactive Pop-up Modal for School Profiles (Direção, Professores, Alunos)
 * - Central Ampulheta CLAEX Circuit Hub Inspector
 * - Single-Accent Switcher (Academic Blue / Opticore Violet / Edge Amber)
 * - Schedule Conflict Simulator & RBAC Switcher
 */

(function () {
    'use strict';

    // 1. SINGLE-ACCENT TONE CONTROLLER (COR ÚNICA, SEM MISTURA)
    function initSingleAccentController() {
        const accents = ['blue', 'violet', 'amber'];
        const labels = {
            blue: 'Cor: Azul Escolar',
            violet: 'Cor: Violeta Opticore',
            amber: 'Cor: Âmbar Edge'
        };

        const savedAccent = localStorage.getItem('claex_single_accent') || 'blue';
        const applyAccent = (accent) => {
            if (accent === 'amber' || accent === 'violet') {
                document.documentElement.setAttribute('data-accent', accent);
                document.body.setAttribute('data-accent', accent);
            } else {
                document.documentElement.removeAttribute('data-accent');
                document.body.removeAttribute('data-accent');
            }
            const label = document.getElementById('accentLabel');
            if (label) {
                label.textContent = labels[accent] || labels.blue;
            }
        };

        applyAccent(savedAccent);

        const btn = document.getElementById('accentSwitchBtn');
        if (btn) {
            btn.addEventListener('click', () => {
                const current = document.body.getAttribute('data-accent') || 'blue';
                const nextIdx = (accents.indexOf(current) + 1) % accents.length;
                const next = accents[nextIdx];
                localStorage.setItem('claex_single_accent', next);
                applyAccent(next);
            });
        }
    }

    // 2. POP-UP MODAL INTERATIVO ("DESENVOLVIDO PARA ESCOLAS E PROFESSORES")
    function initProfilePopupModal() {
        const overlay = document.getElementById('claex-profile-popup');
        const closeBtn = document.getElementById('claex-popup-close');
        const cancelBtn = document.getElementById('claex-popup-cancel');
        const triggers = document.querySelectorAll('[data-popup-role]');

        if (!overlay || !triggers.length) return;

        const profileData = {
            direcao: {
                icon: '🏫',
                tag: 'Gestão Institucional',
                title: 'Direção & Coordenação',
                desc: 'Controle todas as salas, durações de aula, intervalos e gere grades completas sem planilhas manuais através do Motor CLAEX.',
                items: [
                    'Gestão completa de salas, laboratórios e turmas',
                    'Geração automática de grade com o Motor CLAEX',
                    'Ensino de regras pedagógicas para a IA Gemini',
                    'Auditoria automática contra choques de horários'
                ],
                ctaText: 'Abrir Painel de Salas →',
                ctaHref: 'listar_sala.html'
            },
            professor: {
                icon: '👩‍🏫',
                tag: 'Autonomia Docente',
                title: 'Corpo Docente',
                desc: 'Autonomia para registrar horários disponíveis e matérias que leciona, garantindo uma grade justa, equilibrada e sem sobrecarga.',
                items: [
                    'Cadastro próprio de dias e horários disponíveis',
                    'Proteção Motor CLAEX: nunca passa de 2 aulas seguidas',
                    'Proibição de alocar o mesmo professor o dia inteiro na sala',
                    'Sincronização entre diferentes escolas onde leciona'
                ],
                ctaText: 'Acessar Área do Professor →',
                ctaHref: 'painel_professor.html'
            },
            aluno: {
                icon: '🎓',
                tag: 'Portal Estudantil',
                title: 'Estudantes & Turmas',
                desc: 'Acesso rápido, limpo e somente-leitura à matriz oficial de horários da sua sala, com disciplinas, professores e intervalos.',
                items: [
                    'Consulta em tempo real da grade oficial da turma',
                    'Equilíbrio cognitivo de disciplinas ao longo do dia',
                    'Visualização protegida (somente leitura)',
                    'Acesso imediato pelo computador ou celular'
                ],
                ctaText: 'Consultar Grades →',
                ctaHref: 'listar_sala.html'
            }
        };

        const openModal = (roleKey) => {
            const data = profileData[roleKey];
            if (!data) return;

            document.getElementById('popup-modal-icon').textContent = data.icon;
            document.getElementById('popup-modal-tag').textContent = data.tag;
            document.getElementById('popup-modal-title').textContent = data.title;
            document.getElementById('popup-modal-desc').textContent = data.desc;

            const listEl = document.getElementById('popup-modal-list');
            listEl.innerHTML = data.items
                .map(item => `<li><span class="check">✓</span> <span>${item}</span></li>`)
                .join('');

            const ctaEl = document.getElementById('popup-modal-cta');
            if (ctaEl) {
                ctaEl.textContent = data.ctaText;
                ctaEl.setAttribute('href', data.ctaHref);
            }

            overlay.classList.add('open');
            overlay.setAttribute('aria-hidden', 'false');
        };

        const closeModal = () => {
            overlay.classList.remove('open');
            overlay.setAttribute('aria-hidden', 'true');
        };

        triggers.forEach(card => {
            card.addEventListener('click', () => {
                openModal(card.getAttribute('data-popup-role'));
            });
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    openModal(card.getAttribute('data-popup-role'));
                }
            });
        });

        if (closeBtn) closeBtn.addEventListener('click', closeModal);
        if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeModal();
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && overlay.classList.contains('open')) {
                closeModal();
            }
        });
    }

    // 3. INTERACTIVE AMPULHETA CLAEX CIRCUIT HUB INSPECTOR
    function initAiHubDiagram() {
        const stage = document.getElementById('ai-hub-diagram');
        const inspectorText = document.getElementById('hub-inspector-text');
        if (!stage || !inspectorText) return;

        const nodes = stage.querySelectorAll('[data-hub-info]');
        nodes.forEach(node => {
            const updateInfo = () => {
                stage.querySelectorAll('.hub-sat-node').forEach(n => n.classList.remove('active'));
                if (node.classList.contains('hub-sat-node')) {
                    node.classList.add('active');
                }
                const info = node.getAttribute('data-hub-info');
                if (info) {
                    inspectorText.innerHTML = info;
                }
            };
            node.addEventListener('mouseenter', updateInfo);
            node.addEventListener('click', updateInfo);
        });
    }

    // 4. PROXIMITY SPOTLIGHT & 3D TILT CARDS
    function initSpotlightAndTiltCards() {
        const cards = document.querySelectorAll('.spotlight-card');
        if (!cards.length) return;

        window.addEventListener('mousemove', (e) => {
            cards.forEach(card => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                card.style.setProperty('--mouse-x', `${x}px`);
                card.style.setProperty('--mouse-y', `${y}px`);
            });
        }, { passive: true });

        const tiltCards = document.querySelectorAll('[data-tilt]');
        if (window.matchMedia('(pointer: fine)').matches) {
            tiltCards.forEach(card => {
                card.addEventListener('mousemove', (e) => {
                    const rect = card.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;
                    const centerX = rect.width / 2;
                    const centerY = rect.height / 2;
                    const rotateX = ((y - centerY) / centerY) * -2.8;
                    const rotateY = ((x - centerX) / centerX) * 2.8;

                    card.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-3px)`;
                });

                card.addEventListener('mouseleave', () => {
                    card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)';
                });
            });
        }
    }

    // 5. INTERACTIVE RBAC PREVIEW SWITCHER
    function initRbacPreview() {
        const tabs = document.querySelectorAll('.rbac-tab');
        const output = document.getElementById('rbac-live-output');
        if (!tabs.length || !output) return;

        const messages = {
            admin: '[DIREÇÃO / ADMIN] Acesso total: cadastra salas, gerencia professores, ensina regras à IA Gemini e gera as grades pelo Motor CLAEX.',
            prof: '[PROFESSOR] Cadastra seus próprios dias/horários disponíveis e disciplinas no Painel do Professor e visualiza as grades.',
            aluno: '[ALUNO] Consulta rápida, limpa e somente-leitura da grade horária oficial da sua turma.'
        };

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                const role = tab.getAttribute('data-rbac-role');
                if (messages[role]) {
                    output.style.opacity = '0.4';
                    setTimeout(() => {
                        output.textContent = messages[role];
                        output.style.opacity = '1';
                    }, 100);
                }
            });
        });
    }

    // 6. SCHEDULE SIMULATOR WIDGET (MOTOR CLAEX)
    function initScheduleSimulator() {
        const container = document.getElementById('claex-interactive-simulator');
        if (!container) return;

        const slots = container.querySelectorAll('.sim-slot');
        const telemetryStatus = container.querySelector('#sim-telemetry-status');
        const telemetryLog = container.querySelector('#sim-telemetry-log');
        const solveBtn = container.querySelector('#sim-solve-btn');

        slots.forEach(slot => {
            slot.addEventListener('click', () => {
                const isConflict = slot.classList.contains('conflict');
                if (isConflict) {
                    slot.classList.remove('conflict');
                    slot.classList.add('resolved');
                    slot.innerHTML = `<span class="slot-badge">OK</span> ${slot.dataset.subject} <small style="display:block;font-size:.65rem;color:var(--text-secondary)">Equilibrado</small>`;
                    if (telemetryStatus) {
                        telemetryStatus.textContent = 'GRADE EQUILIBRADA (PADRÃO MOTOR CLAEX)';
                    }
                    if (telemetryLog) {
                        telemetryLog.textContent = `[RESOLVIDO] Aula de ${slot.dataset.subject} (${slot.dataset.day} ${slot.dataset.time}) ajustada respeitando máx. 2 aulas seguidas.`;
                    }
                } else if (slot.classList.contains('resolved')) {
                    slot.classList.remove('resolved');
                    slot.innerHTML = `<span class="slot-badge">LIVRE</span> ${slot.dataset.subject} <small style="display:block;font-size:.65rem;color:var(--text-muted)">Disponível</small>`;
                } else {
                    slot.classList.add('conflict');
                    slot.innerHTML = `<span class="slot-badge">CHOQUE</span> ${slot.dataset.subject} <small style="display:block;font-size:.65rem;color:#fca5a5">>2 Seguidas</small>`;
                    if (telemetryStatus) {
                        telemetryStatus.textContent = 'ALERTA: RESTRIÇÃO DETECTADA';
                    }
                    if (telemetryLog) {
                        telemetryLog.textContent = `[BLOQUEIO MOTOR CLAEX] Docente excederia o limite de 2 aulas seguidas ou teria choque entre unidades.`;
                    }
                }
            });
        });

        if (solveBtn) {
            solveBtn.addEventListener('click', () => {
                const conflicts = container.querySelectorAll('.sim-slot.conflict');
                conflicts.forEach(slot => {
                    slot.classList.remove('conflict');
                    slot.classList.add('resolved');
                    slot.innerHTML = `<span class="slot-badge">OK</span> ${slot.dataset.subject} <small style="display:block;font-size:.65rem;color:var(--text-secondary)">Confirmado</small>`;
                });
                if (telemetryStatus) {
                    telemetryStatus.textContent = 'GRADE 100% OTIMIZADA PELO MOTOR CLAEX + IA';
                }
                if (telemetryLog) {
                    telemetryLog.textContent = '[SINCRONIZADO] Horários distribuídos pelo Motor CLAEX: máx. 2 aulas seguidas por docente e 0 conflitos.';
                }
            });
        }
    }

    // 7. GLOBAL NAVIGATION DRAWER
    function initNavigation() {
        const bars = document.querySelectorAll('.bars, .menu-icon, #menuToggle');
        const sideMenu = document.querySelector('#side-menu');
        const overlay = document.querySelector('.menu-overlay');

        function toggleMenu() {
            if (sideMenu) {
                sideMenu.classList.toggle('open');
                if (overlay) overlay.classList.toggle('open');
            }
        }

        bars.forEach(bar => bar.addEventListener('click', toggleMenu));

        if (overlay) {
            overlay.addEventListener('click', () => {
                if (sideMenu) sideMenu.classList.remove('open');
                overlay.classList.remove('open');
            });
        }

        const closeMenu = document.querySelector('.close-menu');
        if (closeMenu) {
            closeMenu.addEventListener('click', () => {
                if (sideMenu) sideMenu.classList.remove('open');
                if (overlay) overlay.classList.remove('open');
            });
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        initSingleAccentController();
        initProfilePopupModal();
        initAiHubDiagram();
        initSpotlightAndTiltCards();
        initRbacPreview();
        initScheduleSimulator();
        initNavigation();
    });
})();
