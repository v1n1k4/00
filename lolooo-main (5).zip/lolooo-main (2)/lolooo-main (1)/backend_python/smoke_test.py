import asyncio, os, tempfile
os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.mkdtemp(), "t.db").replace("\\", "/")
import httpx
import main


async def run():
    main.startup()  # cria tabelas e seed (ASGITransport não executa lifespan)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=main.app), base_url="http://t", timeout=30) as c:
        def show(n, r):
            print(n, r.status_code, r.text[:150].replace("\n", " "), flush=True)

        show("login", await c.post("/login/entrar", params={"login": "admin@claex.com", "senha": "1234"}))
        show("login errado", await c.post("/login/entrar", params={"login": "admin@claex.com", "senha": "x"}))
        show("cad prof", await c.post("/form_cadastro-html/salvar", params={"nome": "Ana", "email": "a@a.com", "senha": "x", "tipo": "professor"}))
        show("cad dup", await c.post("/form_cadastro-html/salvar", params={"nome": "Ana", "email": "a@a.com", "senha": "x"}))
        mats = (await c.get("/materias/listar")).json(); profs = (await c.get("/professores/listar")).json()
        print("materias", len(mats), "professores", len(profs), flush=True)
        show("sala", await c.post("/salas/salvar", json={"nome_sala": "1A", "duracao_aula": 50, "duracao_intervalo": 10, "quant_aula": 5, "inicio_aula": "07:30"}))
        show("sala get", await c.get("/salas/1"))
        payload = [{"id_materia": {"id_materia": m["id_materia"]}, "id_professor": {"id_professor": profs[0]["id_professor"]}} for m in mats[:3]]
        show("gerar", await c.post("/grade/gerargrade/1", json=payload))
        g = (await c.get("/grade/buscar/1")).json(); print("grade dias", len(g), "periodos", len(g[0]), flush=True)
        show("disp", await c.post("/professor/disponibilidade", json={"idProfessor": 2, "diaSemana": "Segunda-feira", "horarioInicial": "08:00", "horarioFinal": "10:00"}))
        show("disp overlap", await c.post("/professor/disponibilidade", json={"idProfessor": 2, "diaSemana": "Segunda-feira", "horarioInicial": "09:00", "horarioFinal": "11:00"}))
        show("mat vinc", await c.post("/professor/materias", json={"idProfessor": 2, "nomeMateria": "Matemática"}))
        show("mat dup", await c.post("/professor/materias", json={"idProfessor": 2, "nomeMateria": "matemática"}))
        show("mat list", await c.get("/professor/materias", params={"idProfessor": 2}))
        show("sala del", await c.delete("/salas/1"))
        show("static", await c.get("/"))

asyncio.run(run())
