"""CLAEX - back-end em Python (FastAPI + SQLAlchemy).

Reimplementação do back-end Spring Boot mantendo as mesmas rotas e o mesmo
formato JSON, para o front-end existente funcionar sem alterações.

Rodar:  uvicorn main:app --reload --port 8080
"""
import os
import random
from datetime import datetime, time
from pathlib import Path
from typing import Any, Optional

from fastapi import Body, Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import (Column, DateTime, ForeignKey, Integer, String, Time,
                        create_engine, func)
from sqlalchemy.orm import Session, declarative_base, relationship, sessionmaker
from starlette.middleware.sessions import SessionMiddleware

# ----------------------------------------------------------------- banco
# Padrão: SQLite local. Para MySQL: DATABASE_URL=mysql+pymysql://root:@localhost:3307/crud_clientes
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/claex_db.sqlite")
if DATABASE_URL.startswith("sqlite"):
    Path("data").mkdir(exist_ok=True)
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(bind=engine, autoflush=False)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ----------------------------------------------------------------- modelos
class Cadastro(Base):
    __tablename__ = "tbl_cadastro"
    id = Column(Integer, primary_key=True, autoincrement=True)
    nome = Column(String(180), nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    senha = Column(String(255), nullable=False)
    tipo = Column(String(50), nullable=False)


class Professor(Base):
    __tablename__ = "tbl_professor"
    id_professor = Column(Integer, primary_key=True, autoincrement=True)
    nome_professor = Column(String(255), nullable=False)
    email_professor = Column(String(255), nullable=False)
    senha_professor = Column(String(255), nullable=False)


class Materia(Base):
    __tablename__ = "tbl_materias"
    id_materia = Column(Integer, primary_key=True, autoincrement=True)
    nome_materia = Column(String(255), nullable=False)


class Sala(Base):
    __tablename__ = "tbl_salas"
    id_sala = Column(Integer, primary_key=True, autoincrement=True)
    nome_sala = Column(String(255), nullable=False)
    duracao_aula = Column(Integer, nullable=False)
    duracao_intervalo = Column(Integer, nullable=False)
    quant_aula = Column(Integer, nullable=False)
    inicio_aula = Column(Time, nullable=False)
    id_escola = Column(Integer, ForeignKey("tbl_cadastro.id"))
    escola = relationship("Cadastro")


class Grade(Base):
    __tablename__ = "tbl_grade"
    id = Column(Integer, primary_key=True, autoincrement=True)
    id_sala = Column(Integer, ForeignKey("tbl_salas.id_sala"))
    sala = relationship("Sala")
    data_grade = Column(DateTime, default=datetime.now)


class Aula(Base):
    __tablename__ = "tbl_aula"
    id_aula = Column(Integer, primary_key=True, autoincrement=True)
    id_grade = Column(Integer, ForeignKey("tbl_grade.id"))
    dia = Column(Integer, nullable=False)
    periodo = Column(Integer, nullable=False)
    id_materia_fk = Column("id_materia", Integer, ForeignKey("tbl_materias.id_materia"))
    id_professor_fk = Column("id_professor", Integer, ForeignKey("tbl_professor.id_professor"))
    grade = relationship("Grade")
    materia = relationship("Materia")
    professor = relationship("Professor")


class Disponibilidade(Base):
    __tablename__ = "tbl_disponibilidade_professor"
    id = Column(Integer, primary_key=True, autoincrement=True)
    id_professor = Column(Integer, ForeignKey("tbl_cadastro.id"), nullable=False)
    professor = relationship("Cadastro")
    diaSemana = Column(String(20), nullable=False)
    horarioInicial = Column(Time, nullable=False)
    horarioFinal = Column(Time, nullable=False)
    modalidade = Column(String(20), nullable=False)
    observacao = Column(String(255))
    status = Column(String(20), nullable=False, default="Disponível")


class MateriaProfessor(Base):
    __tablename__ = "tbl_materia_professor"
    id = Column(Integer, primary_key=True, autoincrement=True)
    id_professor = Column(Integer, ForeignKey("tbl_cadastro.id"), nullable=False)
    id_materia = Column(Integer, ForeignKey("tbl_materias.id_materia"), nullable=False)
    professor = relationship("Cadastro")
    materia = relationship("Materia")
    nivelEnsino = Column(String(255), nullable=False)
    experiencia = Column(String(255), nullable=False)
    descricao = Column(String(500))


class Auditoria(Base):
    __tablename__ = "tbl_auditoria"
    id = Column(Integer, primary_key=True, autoincrement=True)
    usuario = Column(String(255))
    acao = Column(String(255))
    detalhe = Column(String(255))
    dataHora = Column(DateTime, default=datetime.now)


# ----------------------------------------------------------------- serialização
def t(v: Optional[time]):
    return v.strftime("%H:%M:%S") if v else None


def s_cadastro(c: Optional[Cadastro]):
    if not c:
        return None
    return {"id": c.id, "nome": c.nome, "email": c.email, "senha": c.senha, "tipo": c.tipo}


def s_professor(p: Optional[Professor]):
    if not p:
        return None
    return {"id_professor": p.id_professor, "nome_professor": p.nome_professor,
            "email_professor": p.email_professor, "senha_professor": p.senha_professor}


def s_materia(m: Optional[Materia]):
    if not m:
        return None
    return {"id_materia": m.id_materia, "nome_materia": m.nome_materia}


def s_sala(s: Optional[Sala]):
    if not s:
        return None
    return {"id_sala": s.id_sala, "nome_sala": s.nome_sala, "duracao_aula": s.duracao_aula,
            "duracao_intervalo": s.duracao_intervalo, "quant_aula": s.quant_aula,
            "inicio_aula": t(s.inicio_aula), "escola": s_cadastro(s.escola)}


def s_grade(g: Optional[Grade]):
    if not g:
        return None
    return {"id": g.id, "sala": s_sala(g.sala),
            "data_grade": g.data_grade.isoformat() if g.data_grade else None}


def s_aula(a: Optional[Aula]):
    if a is None:
        return None
    return {"id_aula": a.id_aula, "grade": s_grade(a.grade), "dia": a.dia, "periodo": a.periodo,
            "id_materia": s_materia(a.materia), "id_professor": s_professor(a.professor)}


def s_disp(d: Disponibilidade):
    return {"id": d.id, "professor": s_cadastro(d.professor), "diaSemana": d.diaSemana,
            "horarioInicial": t(d.horarioInicial), "horarioFinal": t(d.horarioFinal),
            "modalidade": d.modalidade, "observacao": d.observacao, "status": d.status}


def s_mp(m: MateriaProfessor):
    return {"id": m.id, "professor": s_cadastro(m.professor), "materia": s_materia(m.materia),
            "nivelEnsino": m.nivelEnsino, "experiencia": m.experiencia, "descricao": m.descricao}


def parse_time(v: Any) -> time:
    v = str(v)
    if len(v) == 5:
        v += ":00"
    return time.fromisoformat(v)


# ----------------------------------------------------------------- serviços
def auditar(db: Session, usuario: str, acao: str, detalhe: str):
    db.add(Auditoria(usuario=usuario, acao=acao, detalhe=detalhe))
    db.commit()


def sincronizar_professor(db: Session, c: Cadastro):
    if (c.tipo or "").lower() != "professor":
        return
    p = (db.query(Professor)
         .filter(func.lower(Professor.email_professor) == c.email.lower()).first()) or Professor()
    p.nome_professor, p.email_professor, p.senha_professor = c.nome, c.email, c.senha
    db.add(p)
    db.commit()


def seed():
    db = SessionLocal()
    try:
        for nome in ["Português", "Matemática", "Física", "Química", "Biologia", "História",
                     "Geografia", "Sociologia", "Filosofia", "Educação Física", "Artes",
                     "Língua Inglesa", "Língua Espanhola"]:
            if not db.query(Materia).filter(func.lower(Materia.nome_materia) == nome.lower()).first():
                db.add(Materia(nome_materia=nome))
        db.commit()
        if not db.query(Cadastro).filter_by(email="admin@claex.com").first():
            db.add(Cadastro(nome="Administrador CLAEX", email="admin@claex.com",
                            senha="1234", tipo="administrador"))
            db.commit()
        for c in db.query(Cadastro).all():
            sincronizar_professor(db, c)
    finally:
        db.close()


# ----------------------------------------------------------------- algoritmo de grade
def criar_grade(materias: list, quant_aulas: int):
    """materias: lista de dicts {materia: Materia|None, professor: Professor|None}"""
    total = 5 * quant_aulas
    pool = []
    if materias:
        while len(pool) < total:
            for m in materias:
                pool.append(dict(m))
                if len(pool) >= total:
                    break
    grade = []
    for d in range(5):
        dia = []
        for p in range(quant_aulas):
            if pool:
                item = pool.pop(random.randrange(len(pool)))
                item["dia"], item["periodo"] = d, p
                dia.append(item)
            else:
                dia.append(None)
        grade.append(dia)
    return grade


def conflitos(grade, existentes):
    pontos = 0
    for outra in existentes:
        for i in range(min(5, len(outra), len(grade))):
            for a in range(min(len(grade[i]), len(outra[i]))):
                a1, a2 = grade[i][a], outra[i][a]
                if a1 and a2 and a1.get("professor") and a2.get("professor"):
                    if a1["professor"].id_professor == a2["professor"].id_professor:
                        pontos -= 5
    return pontos


def aulas_seguidas(grade):
    total = 0
    for dia in grade:
        for i in range(len(dia) - 1):
            a, b = dia[i], dia[i + 1]
            if a and b and a.get("materia") and b.get("materia") \
                    and a["materia"].id_materia == b["materia"].id_materia and i % 2 == 0:
                total += 3
    return total


def validar(grade, existentes):
    return aulas_seguidas(grade) + conflitos(grade, existentes)


def mutar(grade):
    g = [list(d) for d in grade]
    if not g or not g[0]:
        return g
    r1, r2 = random.randrange(len(g)), random.randrange(len(g[0]))
    r3, r4 = random.randrange(len(g)), random.randrange(len(g[0]))
    g[r1][r2], g[r3][r4] = g[r3][r4], g[r1][r2]
    return g


def evoluir(grade, existentes, geracoes, individuos):
    melhor = [list(d) for d in grade]
    score = validar(melhor, existentes)
    for _ in range(geracoes):
        for indv in [mutar(melhor) for _ in range(individuos)]:
            sc = validar(indv, existentes)
            if score < sc:
                melhor, score = [list(d) for d in indv], sc
    return melhor


def buscar_grade(db: Session, id_sala_ou_grade: int):
    """Retorna matriz [dia][periodo] de Aula (ou None), como o original."""
    g = (db.query(Grade).filter(Grade.id_sala == id_sala_ou_grade)
         .order_by(Grade.id.desc()).first()) or db.get(Grade, id_sala_ou_grade)
    if not g or not g.sala:
        return []
    qa = g.sala.quant_aula if g.sala.quant_aula > 0 else 5
    aulas = db.query(Aula).filter(Aula.id_grade == g.id).all()
    if not aulas:
        return []
    matriz = [[None] * qa for _ in range(5)]
    for a in aulas:
        if 0 <= a.dia < 5 and 0 <= a.periodo < qa:
            matriz[a.dia][a.periodo] = a
    return matriz


def grades_da_escola(db: Session, sala: Sala):
    res = []
    if sala.id_escola:
        for outra in db.query(Sala).filter(Sala.id_escola == sala.id_escola).all():
            if outra.id_sala != sala.id_sala:
                g = buscar_grade(db, outra.id_sala)
                if g:
                    # converte para o formato interno do algoritmo
                    res.append([[({"professor": a.professor, "materia": a.materia} if a else None)
                                 for a in dia] for dia in g])
    return res


# ----------------------------------------------------------------- app
app = FastAPI(title="CLAEX")
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SECRET_KEY", "claex-dev-secret"))
app.add_middleware(CORSMiddleware, allow_origin_regex=".*", allow_credentials=True,
                   allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    Base.metadata.create_all(engine)
    seed()


def erro(status: int, msg: str):
    return PlainTextResponse(msg, status_code=status)


# ---- cadastro
@app.post("/form_cadastro-html/salvar")
def cad_salvar(nome: str, email: str, senha: str, tipo: str = "aluno", db: Session = Depends(get_db)):
    if db.query(Cadastro).filter_by(email=email).first():
        return erro(400, "Erro: O e-mail informado já está cadastrado!")
    try:
        c = Cadastro(nome=nome, email=email, senha=senha, tipo=tipo)
        db.add(c)
        db.commit()
        sincronizar_professor(db, c)
        return PlainTextResponse("Cadastro realizado com sucesso!")
    except Exception as e:
        db.rollback()
        return erro(500, f"Erro interno no servidor: {e}")


@app.get("/form_cadastro-html/listar")
def cad_listar(db: Session = Depends(get_db)):
    return [s_cadastro(c) for c in db.query(Cadastro).all()]


@app.put("/form_cadastro-html/atualizar/{id}")
def cad_atualizar(id: int, nome: Optional[str] = None, senha: Optional[str] = None,
                  tipo: str = "aluno", db: Session = Depends(get_db)):
    c = db.get(Cadastro, id)
    if not c:
        return erro(400, "Erro ao atualizar cadastro: Cadastro não encontrado")
    if nome is not None:
        c.nome = nome
    if senha is not None:
        c.senha = senha
    c.tipo = tipo
    db.commit()
    sincronizar_professor(db, c)
    return PlainTextResponse("Atualizado com sucesso!")


@app.delete("/form_cadastro-html/deletar/{id}")
def cad_deletar(id: int, db: Session = Depends(get_db)):
    c = db.get(Cadastro, id)
    if not c:
        return erro(404, "Registro não encontrado para deleção.")
    try:
        db.delete(c)
        db.commit()
        return PlainTextResponse("Deletado com sucesso!")
    except Exception:
        db.rollback()
        return erro(404, "Registro não encontrado para deleção.")


# ---- login
@app.post("/login/entrar")
def login(login: str, senha: str, request: Request, db: Session = Depends(get_db)):
    u = (db.query(Cadastro).filter_by(nome=login).first()
         or db.query(Cadastro).filter_by(email=login).first())
    if not u:
        return JSONResponse({"erro": "Usuário não cadastrado!"}, status_code=404)
    if u.senha != senha:
        return JSONResponse({"erro": "Senha incorreta!"}, status_code=401)
    request.session["usuarioLogado"] = u.id
    return {"mensagem": "Login realizado com sucesso!", "id": str(u.id), "nome": u.nome,
            "email": u.email, "tipo": u.tipo}


# ---- listagens simples
@app.get("/materias/listar")
def materias_listar(db: Session = Depends(get_db)):
    return [s_materia(m) for m in db.query(Materia).all()]


@app.get("/professores/listar")
def professores_listar(db: Session = Depends(get_db)):
    return [s_professor(p) for p in db.query(Professor).all()]


# ---- salas
def _sala_from_body(sala: Sala, body: dict):
    sala.nome_sala = body.get("nome_sala")
    sala.duracao_aula = int(body.get("duracao_aula", 0))
    sala.duracao_intervalo = int(body.get("duracao_intervalo", 0))
    sala.quant_aula = int(body.get("quant_aula", 0))
    sala.inicio_aula = parse_time(body.get("inicio_aula"))


@app.get("/salas/listar")
def salas_listar(db: Session = Depends(get_db)):
    return [s_sala(s) for s in db.query(Sala).all()]


@app.get("/salas/{id}")
def salas_buscar(id: int, db: Session = Depends(get_db)):
    s = db.get(Sala, id)
    if not s:
        return erro(500, "Sala não encontrada")
    return s_sala(s)


@app.post("/salas/salvar")
def salas_salvar(body: dict = Body(...), db: Session = Depends(get_db)):
    s = Sala()
    _sala_from_body(s, body)
    esc = body.get("escola")
    if isinstance(esc, dict) and esc.get("id"):
        s.id_escola = int(esc["id"])
    db.add(s)
    db.commit()
    db.refresh(s)
    return s_sala(s)


@app.put("/salas/{id}")
def salas_atualizar(id: int, body: dict = Body(...), db: Session = Depends(get_db)):
    s = db.get(Sala, id)
    if not s:
        return erro(500, "Sala não encontrada")
    _sala_from_body(s, body)
    db.commit()
    return s_sala(s)


@app.delete("/salas/{id}")
def salas_deletar(id: int, db: Session = Depends(get_db)):
    s = db.get(Sala, id)
    if s:
        # remove grades/aulas dependentes (o JPA original falharia por FK)
        for g in db.query(Grade).filter_by(id_sala=id).all():
            db.query(Aula).filter_by(id_grade=g.id).delete()
            db.delete(g)
        db.delete(s)
        db.commit()
    return None


# ---- grade
@app.get("/grade/buscar/{id}")
def grade_buscar(id: int, db: Session = Depends(get_db)):
    return [[s_aula(a) for a in dia] for dia in buscar_grade(db, id)]


@app.post("/grade/gerargrade/{id_sala}")
def grade_gerar(id_sala: int, materias: list = Body(...), db: Session = Depends(get_db)):
    sala = db.get(Sala, id_sala)
    if not sala:
        return erro(500, "Sala não encontrada")
    g = Grade(id_sala=id_sala)
    db.add(g)
    db.commit()
    db.refresh(g)

    itens = []
    for m in materias:
        im, ip = m.get("id_materia"), m.get("id_professor")
        itens.append({
            "materia": db.get(Materia, im["id_materia"]) if isinstance(im, dict) and im.get("id_materia") else None,
            "professor": db.get(Professor, ip["id_professor"]) if isinstance(ip, dict) and ip.get("id_professor") else None,
        })
    qa = sala.quant_aula if sala.quant_aula > 0 else 5
    existentes = grades_da_escola(db, sala)
    final = evoluir(criar_grade(itens, qa), existentes, 50, 50)

    saida = []
    for d, dia in enumerate(final):
        linha = []
        for p, it in enumerate(dia):
            if it is None:
                linha.append(None)
                continue
            a = Aula(id_grade=g.id, dia=d, periodo=p,
                     id_materia_fk=it["materia"].id_materia if it["materia"] else None,
                     id_professor_fk=it["professor"].id_professor if it["professor"] else None)
            db.add(a)
            linha.append(a)
        saida.append(linha)
    db.commit()
    return [[s_aula(a) for a in dia] for dia in saida]


# ---- área do professor
def resolver_prof(db: Session, request: Request, id_professor: Optional[int]) -> Optional[Cadastro]:
    uid = request.session.get("usuarioLogado")
    if uid:
        c = db.get(Cadastro, uid)
        if c:
            return c
    return db.get(Cadastro, id_professor) if id_professor is not None else None


NAO_IDENT = "Professor não identificado."


@app.get("/professor/disponibilidade")
def disp_listar(request: Request, idProfessor: Optional[int] = None, db: Session = Depends(get_db)):
    p = resolver_prof(db, request, idProfessor)
    if not p:
        return erro(401, "Professor não identificado. Faça login novamente.")
    return [s_disp(d) for d in db.query(Disponibilidade).filter_by(id_professor=p.id).all()]


@app.post("/professor/disponibilidade")
def disp_salvar(request: Request, body: dict = Body(...), idProfessor: Optional[int] = None,
                db: Session = Depends(get_db)):
    try:
        idp = idProfessor if idProfessor is not None else (
            int(body["idProfessor"]) if body.get("idProfessor") is not None else None)
        p = resolver_prof(db, request, idp)
        if not p:
            return erro(401, NAO_IDENT)
        ini, fim = parse_time(body.get("horarioInicial")), parse_time(body.get("horarioFinal"))
        dia = str(body.get("diaSemana", "Segunda-feira"))
        if not fim > ini:
            return erro(400, "O horário final deve ser posterior ao horário inicial.")
        for it in db.query(Disponibilidade).filter_by(id_professor=p.id, diaSemana=dia).all():
            if ini < it.horarioFinal and fim > it.horarioInicial:
                return erro(400, "Já existe um intervalo sobreposto ou duplicado para este dia.")
        d = Disponibilidade(id_professor=p.id, diaSemana=dia, horarioInicial=ini, horarioFinal=fim,
                            modalidade=str(body.get("modalidade", "Presencial")),
                            observacao=str(body["observacao"]) if body.get("observacao") is not None else "",
                            status="Disponível")
        db.add(d)
        db.commit()
        db.refresh(d)
        auditar(db, p.nome, "CADASTRAR_DISPONIBILIDADE", f"Cadastrou intervalo no dia {dia}")
        return s_disp(d)
    except Exception as e:
        db.rollback()
        return erro(400, f"Erro ao salvar disponibilidade: {e}")


@app.delete("/professor/disponibilidade/{id}")
def disp_deletar(id: int, request: Request, idProfessor: Optional[int] = None,
                 db: Session = Depends(get_db)):
    p = resolver_prof(db, request, idProfessor)
    if not p:
        return erro(401, NAO_IDENT)
    d = db.get(Disponibilidade, id)
    if not d:
        return erro(500, "Registro não encontrado")
    if d.id_professor != p.id:
        return erro(403, "Operação não autorizada para este perfil.")
    db.delete(d)
    db.commit()
    auditar(db, p.nome, "REMOVER_DISPONIBILIDADE", f"Removeu registro #{id}")
    return PlainTextResponse("Disponibilidade removida com sucesso!")


@app.get("/professor/materias")
def mp_listar(request: Request, idProfessor: Optional[int] = None, db: Session = Depends(get_db)):
    p = resolver_prof(db, request, idProfessor)
    if not p:
        return erro(401, NAO_IDENT)
    return [s_mp(m) for m in db.query(MateriaProfessor).filter_by(id_professor=p.id).all()]


@app.post("/professor/materias")
def mp_vincular(request: Request, body: dict = Body(...), idProfessor: Optional[int] = None,
                db: Session = Depends(get_db)):
    try:
        idp = idProfessor if idProfessor is not None else (
            int(body["idProfessor"]) if body.get("idProfessor") is not None else None)
        p = resolver_prof(db, request, idp)
        if not p:
            return erro(401, NAO_IDENT)
        nome = str(body["nomeMateria"]).strip() if body.get("nomeMateria") is not None else ""
        if not nome:
            return erro(400, "Informe o nome da matéria.")
        mat = db.query(Materia).filter(func.lower(Materia.nome_materia) == nome.lower()).first()
        if not mat:
            mat = Materia(nome_materia=nome)
            db.add(mat)
            db.commit()
            db.refresh(mat)
        if db.query(MateriaProfessor).filter_by(id_professor=p.id, id_materia=mat.id_materia).first():
            return erro(400, "Esta matéria já está vinculada ao seu perfil.")
        mp = MateriaProfessor(id_professor=p.id, id_materia=mat.id_materia,
                              nivelEnsino=str(body.get("nivelEnsino", "Médio")),
                              experiencia=str(body.get("experiencia", "1 ano")),
                              descricao=str(body["descricao"]) if body.get("descricao") is not None else None)
        db.add(mp)
        db.commit()
        db.refresh(mp)
        auditar(db, p.nome, "VINCULAR_MATERIA", f"Vinculou a matéria ID: {mat.id_materia}")
        return s_mp(mp)
    except Exception as e:
        db.rollback()
        return erro(400, f"Erro ao vincular matéria: {e}")


@app.delete("/professor/materias/{id}")
def mp_desvincular(id: int, request: Request, idProfessor: Optional[int] = None,
                   db: Session = Depends(get_db)):
    p = resolver_prof(db, request, idProfessor)
    if not p:
        return erro(401, NAO_IDENT)
    mp = db.get(MateriaProfessor, id)
    if not mp:
        return erro(500, "Vínculo de matéria não encontrado.")
    if mp.id_professor != p.id:
        return erro(403, "Operação não autorizada para este perfil.")
    db.delete(mp)
    db.commit()
    auditar(db, p.nome, "REMOVER_MATERIA", f"Desvinculou o registro de matéria #{id}")
    return PlainTextResponse("Matéria desvinculada com sucesso!")


# ---- front-end estático (só leitura; aponta para a pasta do projeto original)
STATIC_DIR = Path(os.getenv(
    "STATIC_DIR",
    Path(__file__).resolve().parent.parent / "lolooo-main" / "src" / "main" / "resources" / "static"))
if STATIC_DIR.exists():
    app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
